import React from 'react';
import { Link } from 'react-router-dom';
import * as taskService from './taskService';
import './styles.css'; // Import the styles

const Task = ({ task, onDelete }) => {
  const handleDelete = () => {
    onDelete(task.id);
  };

  const handleMarkComplete = () => {
    taskService.markTaskComplete(task.id);
  };

  const handleMarkIncomplete = () => {
    taskService.markTaskIncomplete(task.id);
  };

  return (
    <div className="task-card">
      <h3>{task.title}</h3>
      <p>{task.description}</p>
      <p>Status: {task.completed ? 'Completed' : 'Incomplete'}</p>
      <div className="button-group">
        <Link to={`/update/${task.id}`} className="button button-edit">
          Edit
        </Link>
        <button
          className="button button-mark-complete"
          onClick={handleMarkComplete}
          disabled={task.completed}
        >
          Mark Complete
        </button>
        <button
          className="button button-mark-incomplete"
          onClick={handleMarkIncomplete}
          disabled={!task.completed}
        >
          Mark Incomplete
        </button>
        <button className="button button-delete" onClick={handleDelete}>
          Delete
        </button>
      </div>
    </div>
  );
};

export default Task;
