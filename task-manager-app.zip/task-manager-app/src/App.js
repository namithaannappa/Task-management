import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import TaskList from './TaskList';
import TaskForm from './TaskForm';
import * as taskService from './taskService';

const App = () => {
  const [tasks, setTasks] = useState(taskService.getTasks());

  const addTask = (task) => {
    taskService.addTask({ ...task, id: tasks.length + 1, completed: false });
    setTasks(taskService.getTasks());
  };

  const updateTask = (updatedTask) => {
    taskService.updateTask(updatedTask);
    setTasks(taskService.getTasks());
  };

  const deleteTask = (taskId) => {
    taskService.deleteTask(taskId);
    setTasks(taskService.getTasks());
  };

  return (
    <Router>
      <Switch>
        <Route
          path="/"
          exact
          render={() => <TaskList tasks={tasks} onDelete={deleteTask} />}
        />
        <Route path="/create" render={() => <TaskForm onSubmit={addTask} />} />
        <Route
          path="/update/:taskId"
          render={({ match }) => {
            const taskId = parseInt(match.params.taskId, 10);
            const task = tasks.find((t) => t.id === taskId);
            return <TaskForm onSubmit={updateTask} initialTask={task} />;
          }}
        />
      </Switch>
    </Router>
  );
};

export default App;
