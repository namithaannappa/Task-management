import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { CSSTransition } from 'react-transition-group';
import './styles.css';

const TaskForm = ({ onSubmit, initialTask }) => {
  const history = useHistory();
  const [title, setTitle] = useState(initialTask ? initialTask.title : '');
  const [description, setDescription] = useState(initialTask ? initialTask.description : '');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ title, description, id: initialTask ? initialTask.id : undefined, completed: false });
    history.push('/'); // Redirect to the main page
  };

  return (
    <div className="container">
      <div className="header">
        <h1>Task Manager</h1>
      </div>
      <CSSTransition in={true} timeout={500} classNames="fade" unmountOnExit>
        <div className="form-container">
          <form onSubmit={handleSubmit} className="task-form">
            <h2 className='createtask'>{initialTask ? 'Edit Task' : 'Create Task'}</h2>
            <label>
              Title:
              <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
            </label>
            <label>
              Description:
              <textarea
                rows="8"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </label>
            <div className="button-group">
              <button type="submit" className="button">
                {initialTask ? 'Update Task' : 'Create Task'}
              </button>
              <button
                type="button"
                className="button button-secondary"
                onClick={() => history.push('/')}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </CSSTransition>
    </div>
  );
};

export default TaskForm;
