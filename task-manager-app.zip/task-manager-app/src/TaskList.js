import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import './animations.css';
import './styles.css';

import Task from './Task';
import * as taskService from './taskService';

const TaskList = () => {
  const [tasks, setTasks] = useState(taskService.getTasks());

  const onDelete = (taskId) => {
    taskService.deleteTask(taskId);
  };

  useEffect(() => {
    const updateCallback = () => {
      setTasks(taskService.getTasks());
    };

    taskService.setUpdateCallback(updateCallback);

    return () => {
      taskService.setUpdateCallback(null);
    };
  }, []);

  return (
    <div>
      <div className="header">
        <h1>Task Manager</h1>
      </div>
      <div className="navbar">
        <Link to="/">Task List</Link>
        <Link to="/create">Create Task</Link>
      </div>
      <div className="container">
        <h2>Task List</h2>
        <TransitionGroup>
          {tasks.map((task) => (
            <CSSTransition key={task.id} timeout={500} classNames="fade">
              <div className="task-card">
                <Task task={task} onDelete={onDelete} />
              </div>
            </CSSTransition>
          ))}
        </TransitionGroup>
      </div>
    </div>
  );
};

export default TaskList;
