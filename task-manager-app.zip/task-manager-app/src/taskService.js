const STORAGE_KEY = 'tasks';

// Load tasks from localStorage if available
const tasks = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];

let updateCallback = null;

export const setUpdateCallback = (callback) => {
  updateCallback = callback;
};

const notifyUpdate = () => {
  if (updateCallback) {
    updateCallback();
  }
};

export const getTasks = () => tasks;

export const addTask = (task) => {
  tasks.push(task);
  saveTasksToStorage();
  notifyUpdate();
};

export const updateTask = (updatedTask) => {
  const index = tasks.findIndex((task) => task.id === updatedTask.id);
  if (index !== -1) {
    tasks[index] = updatedTask;
    saveTasksToStorage();
    notifyUpdate();
  }
};

export const deleteTask = (taskId) => {
  const index = tasks.findIndex((task) => task.id === taskId);
  if (index !== -1) {
    tasks.splice(index, 1);
    saveTasksToStorage();
    notifyUpdate();
  }
};

export const markTaskComplete = (taskId) => {
  const index = tasks.findIndex((task) => task.id === taskId);
  if (index !== -1) {
    tasks[index].completed = true;
    saveTasksToStorage();
    notifyUpdate();
  }
};

export const markTaskIncomplete = (taskId) => {
  const index = tasks.findIndex((task) => task.id === taskId);
  if (index !== -1) {
    tasks[index].completed = false;
    saveTasksToStorage();
    notifyUpdate();
  }
};

const saveTasksToStorage = () => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
};
